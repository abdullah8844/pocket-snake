import test from 'node:test';import assert from 'node:assert/strict';import {spawn} from 'node:child_process';import {once} from 'node:events';import {mkdtempSync,rmSync} from 'node:fs';import {tmpdir} from 'node:os';import path from 'node:path';
const base='http://127.0.0.1:18789';
test('two clients, access controls, punch synchronization and restart persistence',async()=>{
 const dir=mkdtempSync(path.join(tmpdir(),'twinlocks-test-'));let child;
 async function start(){child=spawn(process.execPath,['server.mjs'],{cwd:new URL('../',import.meta.url),env:{...process.env,PORT:'18789',DATA_DIR:dir},stdio:['ignore','pipe','pipe']});await Promise.race([once(child.stdout,'data'),once(child,'exit').then(()=>{throw Error('Server exited')}),new Promise((_,rej)=>setTimeout(()=>rej(Error('Server timeout')),5000).unref())])}
 async function stop(){if(child&&child.exitCode===null){const exited=once(child,'exit');child.kill();await exited}}
 async function post(action,data,token,origin){const r=await fetch(base+'/api/'+action,{method:'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{}),...(origin?{Origin:origin}:{})},body:JSON.stringify(data)});return {status:r.status,body:await r.json()}}
 try{
 await start();let r=await post('create',{});assert.equal(r.status,200);const a=r.body;
 r=await post('join',{code:a.code});assert.equal(r.status,200);const b=r.body;
 assert.equal((await post('join',{code:a.code})).status,409);
 assert.equal((await post('move',{code:a.code,dx:1,dy:0},'f'.repeat(48))).status,401);
 assert.equal((await post('move',{code:a.code,dx:1,dy:0},a.token,'https://evil.example')).status,403);
 r=await post('move',{code:a.code,dx:1,dy:0},a.token);assert.equal(r.body.positions[0].x,2);
 r=await post('bonk',{code:a.code},a.token);assert.equal(r.body.hit.to,1);
 const bState=await(await fetch(base+'/api/state?code='+a.code,{headers:{Authorization:'Bearer '+b.token}})).json();assert.equal(bState.hit.id,r.body.hit.id);assert.equal(bState.tokens,undefined);
 await post('next',{code:a.code},a.token);await stop();await start();
 const restored=await(await fetch(base+'/api/state?code='+a.code,{headers:{Authorization:'Bearer '+a.token}})).json();assert.equal(restored.positions[0].x,2);assert.equal(restored.seat,0);assert.equal(restored.code,a.code);
 assert.equal((await fetch(base+'/data/progress.json')).status,404);
 }finally{await stop();rmSync(dir,{recursive:true,force:true})}
});
