import test from 'node:test';import assert from 'node:assert/strict';
import {maze,initStage,move,PAIRS,PADS,publicState,nextStage,activate,bonk} from '../game.mjs';
const room=()=>{const r={code:'AABBCCDDEE',tokens:['a'.repeat(48),'b'.repeat(48)],completed:[],lastSeen:[0,0],ready:[false,false]};initStage(r,0);return r};
function path(map,start,end,blocked){const q=[[start,[]]],seen=new Set();while(q.length){const [p,moves]=q.shift();const key=p.x+','+p.y;if(seen.has(key))continue;seen.add(key);if(p.x===end.x&&p.y===end.y)return moves;for(const [dx,dy]of [[1,0],[-1,0],[0,1],[0,-1]]){const n={x:p.x+dx,y:p.y+dy};if(map[n.y]?.[n.x]==='.'&&!(blocked&&n.x===blocked.x&&n.y===blocked.y))q.push([n,[...moves,[dx,dy]]])}}throw Error('Unreachable target')}
let clock=1000001;function walk(r,i,end){for(const [dx,dy] of path(maze(r.level),r.positions[i],end,r.level===1?r.crates[i]:null)){clock+=300;while(r.level===2&&Math.floor(clock/2500)%2===0)clock+=2500;assert.equal(move(r,i,dx,dy,clock),true)}}
test('all maps and objectives are connected',()=>{for(let l=0;l<3;l++){const map=maze(l);for(const p of [...PADS,{x:7,y:13},{x:1,y:13}])assert.ok(path(map,{x:1,y:1},p).length>0)}});
test('server rejects illegal moves and rate limits',()=>{const r=room();assert.equal(move(r,0,-1,0,1000),false);assert.equal(move(r,0,2,0,1200),false);assert.equal(move(r,0,1,0,1400),true);assert.equal(move(r,0,1,0,1450),false);r.tokens[1]=null;assert.equal(move(r,0,1,0,1600),false)});
test('each player only receives the partner clue',()=>{const r=room();assert.equal(publicState(r,0).partnerTarget,3);assert.equal(publicState(r,1).partnerTarget,1);assert.equal(publicState(r,0).tokens,undefined)});
test('both players can complete every level using legal moves',()=>{const r=room();for(let l=0;l<3;l++){
 assert.equal(r.level,l);
 if(l===1){for(let i=0;i<2;i++){walk(r,i,{x:2,y:1});clock+=300;assert.ok(move(r,i,1,0,clock));clock+=300;assert.ok(move(r,i,1,0,clock))}}
 for(const pair of PAIRS[l]){for(let i=0;i<2;i++)walk(r,i,PADS[pair[i]-1]);activate(r,0);activate(r,1);assert.ok(r.step>0, JSON.stringify({l,pair,step:r.step,notice:r.notice,positions:r.positions,crates:r.crates}))}
 assert.equal(r.step,PAIRS[l].length);
 for(let i=0;i<2;i++){walk(r,i,{x:7,y:13});assert.ok(r.keys[i]);walk(r,i,{x:1,y:13})}
 assert.equal(r.phase,'complete');assert.ok(r.completed.includes(l));if(l<2){nextStage(r,0);assert.equal(r.phase,'complete');nextStage(r,1);assert.equal(r.level,l+1)}
 }});
test('memory stage rolls back to checkpoint on incorrect pair',()=>{const r=room();initStage(r,2);r.step=3;r.checkpoint=2;r.positions=[{...PADS[0]},{x:6,y:3}];clock+=5000;move(r,1,1,0,clock);activate(r,0);activate(r,1);assert.equal(r.step,2)});


test('playful punch stuns briefly without losing puzzle progress',()=>{const r=room();r.step=2;const original={...r.positions[1]};assert.ok(bonk(r,0,10000));assert.equal(bonk(r,0,11000),false);assert.equal(move(r,1,1,0,10500),false);assert.deepEqual(r.positions[1],original);assert.equal(r.step,2);assert.ok(move(r,1,1,0,11100));assert.ok(bonk(r,0,13000))});
