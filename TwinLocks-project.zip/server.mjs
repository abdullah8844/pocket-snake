import http from 'node:http';
import {randomBytes,timingSafeEqual} from 'node:crypto';
import {readFileSync,writeFileSync,renameSync,mkdirSync,existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {initStage,publicState,move,nextStage,activate,bonk} from './game.mjs';
const ROOT=path.dirname(fileURLToPath(import.meta.url));
const DATA=process.env.DATA_DIR||path.join(ROOT,'data');mkdirSync(DATA,{recursive:true});
const SAVE=path.join(DATA,'progress.json');
const rooms=new Map();const rates=new Map();
if(existsSync(SAVE)){
  try{for(const r of JSON.parse(readFileSync(SAVE,'utf8'))){r.lastSeen=[0,0];r.lastMove=[0,0];r.startedAt=Date.now();rooms.set(r.code,r)}}
  catch(e){console.error('Cannot read saved progress. Preserve data/progress.json and repair it before restarting.',e.message);process.exit(1)}
}
let dirty=false;
function save(){if(!dirty)return;const list=[...rooms.values()].map(r=>({...r,elapsed:r.elapsed+(r.phase==='playing'?Date.now()-r.startedAt:0)}));writeFileSync(SAVE+'.tmp',JSON.stringify(list),{mode:0o600});renameSync(SAVE+'.tmp',SAVE);dirty=false}
const interval=setInterval(()=>{save();for(const [k,v]of rates)if(Date.now()-v.at>60000)rates.delete(k)},2000);
function reply(res,status,data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data))}
function auth(room,token){if(!room||typeof token!=='string'||token.length!==48)return -1;return room.tokens.findIndex(t=>typeof t==='string'&&t.length===token.length&&timingSafeEqual(Buffer.from(t),Buffer.from(token)))}
function newCode(){let c;do{c=randomBytes(5).toString('hex').toUpperCase()}while(rooms.has(c));return c}
function roomCode(v){return typeof v==='string'?v.toUpperCase().replace(/[^A-F0-9]/g,'').slice(0,10):''}
const files={'/':['index.html','text/html; charset=utf-8'],'/index.html':['index.html','text/html; charset=utf-8'],'/client.js':['client.js','text/javascript; charset=utf-8'],'/style.css':['style.css','text/css; charset=utf-8'],'/icon.png':['icon.png','image/png'],'/manifest.webmanifest':['manifest.webmanifest','application/manifest+json']};
const server=http.createServer(async(req,res)=>{
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');
  res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
  const url=new URL(req.url,'http://localhost');
  if(req.method==='GET'&&files[url.pathname]){try{const [file,mime]=files[url.pathname];res.writeHead(200,{'Content-Type':mime,'Cache-Control':'no-cache'});res.end(readFileSync(path.join(ROOT,'public',file)))}catch{res.writeHead(404);res.end()}return}
  if(req.method==='GET'&&url.pathname==='/health'){reply(res,200,{ok:true});return}
  if(!url.pathname.startsWith('/api/')){reply(res,404,{error:'غير موجود'});return}
  const ip=req.socket.remoteAddress;let rate=rates.get(ip);if(!rate||Date.now()-rate.at>60000){rate={at:Date.now(),n:0};rates.set(ip,rate)}
  if(++rate.n>1500){reply(res,429,{error:'طلبات كثيرة؛ انتظر قليلًا.'});return}
  try{
    if(req.method==='GET'&&url.pathname==='/api/state'){
      const room=rooms.get(roomCode(url.searchParams.get('code')));const seat=auth(room,req.headers.authorization?.replace(/^Bearer /,''));
      if(seat<0){reply(res,401,{error:'تعذر استعادة الغرفة. تحقق من رمز الاستعادة.'});return}
      room.lastSeen[seat]=Date.now();reply(res,200,publicState(room,seat));return;
    }
    if(req.method!=='POST'){reply(res,405,{error:'طريقة غير مسموحة'});return}
    const origin=req.headers.origin;
    if(origin&&new URL(origin).host!==req.headers.host){reply(res,403,{error:'مصدر الطلب غير مسموح'});return}
    let body='';for await(const chunk of req){body+=chunk;if(body.length>4096){reply(res,413,{error:'طلب كبير'});return}}
    const input=JSON.parse(body||'{}');
    if(url.pathname==='/api/create'){
      if(rooms.size>=200){reply(res,503,{error:'الخادم ممتلئ'});return}
      const token=randomBytes(24).toString('hex');const room={code:newCode(),tokens:[token,null],completed:[],lastSeen:[Date.now(),0],ready:[false,false]};initStage(room,0);rooms.set(room.code,room);dirty=true;save();reply(res,200,{code:room.code,token,seat:0});return;
    }
    const room=rooms.get(roomCode(input.code));
    if(url.pathname==='/api/join'){
      if(!room){reply(res,404,{error:'رمز الغرفة غير صحيح'});return}
      if(room.tokens[1]){reply(res,409,{error:'الغرفة مكتملة. لاستعادة دورك استخدم رمز الاستعادة.'});return}
      const token=randomBytes(24).toString('hex');room.tokens[1]=token;room.lastSeen[1]=Date.now();dirty=true;save();reply(res,200,{code:room.code,token,seat:1});return;
    }
    const seat=auth(room,req.headers.authorization?.replace(/^Bearer /,''));
    if(seat<0){reply(res,401,{error:'جلسة غير صالحة'});return}
    room.lastSeen[seat]=Date.now();
    if(url.pathname==='/api/move'){if(move(room,seat,input.dx,input.dy))dirty=true}
    else if(url.pathname==='/api/link'){if(activate(room,seat))dirty=true}
    else if(url.pathname==='/api/bonk'){if(bonk(room,seat))dirty=true}
    else if(url.pathname==='/api/next'){if(nextStage(room,seat))dirty=true;save()}
    else if(url.pathname==='/api/reset-position'){
      if(room.phase==='playing'){room.positions[seat]={x:1,y:1};if(room.level===1)room.crates[seat]={x:3,y:1};room.lastPair='';dirty=true}
    }else{reply(res,404,{error:'غير موجود'});return}
    reply(res,200,publicState(room,seat));
  }catch{if(!res.headersSent)reply(res,400,{error:'تعذر معالجة الطلب'})}
});
server.requestTimeout=10000;server.headersTimeout=12000;
server.listen(Number(process.env.PORT||8787),'127.0.0.1',()=>console.log('Twin Locks ready: http://127.0.0.1:'+ (process.env.PORT||8787)));
function stop(){dirty=true;save();clearInterval(interval);server.close(()=>process.exit(0));setTimeout(()=>process.exit(0),1500).unref()}
process.on('SIGINT',stop);process.on('SIGTERM',stop);
