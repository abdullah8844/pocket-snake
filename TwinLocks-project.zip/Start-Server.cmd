@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" (
    "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" server.mjs
    pause
    exit /b
  )
  echo Install Node.js LTS from https://nodejs.org then run this file again.
  pause
  exit /b 1
)
node server.mjs
pause
