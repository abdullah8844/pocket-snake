export const TITLES=['حديقة الصدى','ورشة التوازن','برج الذاكرة'];
export const PAIRS=[[[1,3],[2,1],[3,2],[1,2],[3,1],[2,3]],[[3,1],[1,2],[2,3],[3,2],[1,3],[2,1]],[[2,3],[1,2],[3,1],[2,1],[3,2],[1,3],[2,2],[3,3]]];
export const PADS=[{x:7,y:3},{x:1,y:7},{x:7,y:11}];
export const same=(a,b)=>a.x===b.x&&a.y===b.y;
export function maze(level){
  const m=Array.from({length:15},()=>Array(9).fill('#'));
  let seed=913+level*367; const random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296};
  function carve(x,y){m[y][x]='.';const dirs=[[2,0],[-2,0],[0,2],[0,-2]].map(d=>[random(),d]).sort((a,b)=>a[0]-b[0]);for(const [, [dx,dy]] of dirs){const nx=x+dx,ny=y+dy;if(nx>0&&nx<8&&ny>0&&ny<14&&m[ny][nx]==='#'){m[y+dy/2][x+dx/2]='.';carve(nx,ny)}}}
  carve(1,1); for(let x=1;x<8;x++)m[1][x]='.';
  // A second route lets either player get behind a crate if needed.
  for(let x=1;x<8;x++)m[3][x]='.';m[2][1]='.';m[2][7]='.';
  return m.map(row=>row.join(''));
}
export function initStage(room,level=room.level){
  room.level=level;room.step=0;room.positions=[{x:1,y:1},{x:1,y:1}];
  room.crates=[{x:3,y:1},{x:3,y:1}];room.keys=[false,false];room.moves=0;
  room.startedAt=Date.now();room.elapsed=0;room.phase='playing';room.notice='تحدث مع شريكك: كل لاعب يرى الرمز المطلوب من اللاعب الآخر.';
  room.lastPair='';room.lastMove=[0,0];room.checkpoint=0;room.linkReady=[false,false];room.lastHit=[0,0];room.stunnedUntil=[0,0];room.hit=null;
}
export function publicState(room,seat){
  const active=room.phase==='playing';const target=PAIRS[room.level]?.[room.step];
  return {code:room.code,seat,level:room.level,title:TITLES[room.level],phase:room.phase,step:room.step,total:PAIRS[room.level].length,
    map:maze(room.level),positions:room.positions,crates:room.level===1?room.crates:[],keys:room.keys,
    online:room.lastSeen.map(t=>Date.now()-t<10000),elapsed:active?Math.floor((Date.now()-room.startedAt+room.elapsed)/1000):Math.floor(room.elapsed/1000),
    completed:room.completed,moves:room.moves,notice:room.notice,
    partnerTarget:target?target[1-seat]:null,checkpoint:room.checkpoint,
    hazardOn:room.level===2 && Math.floor(Date.now()/2500)%2===0,ready:room.ready,linkReady:room.linkReady,hit:room.hit,stunnedUntil:room.stunnedUntil};
}
export function move(room,seat,dx,dy,now=Date.now()){
  if(room.phase!=='playing'||!room.tokens.every(Boolean)||!Number.isInteger(dx)||!Number.isInteger(dy)||Math.abs(dx)+Math.abs(dy)!==1)return false;
  if(now-room.lastMove[seat]<100||now<(room.stunnedUntil?.[seat]||0))return false;
  room.lastMove[seat]=now;
  const p=room.positions[seat],next={x:p.x+dx,y:p.y+dy};const map=maze(room.level);
  if(map[next.y]?.[next.x]!=='.')return false;
  if(room.level===1&&same(next,room.crates[seat])){
    const beyond={x:next.x+dx,y:next.y+dy};
    if(map[beyond.y]?.[beyond.x]!=='.')return false;
    room.crates[seat]=beyond;
  }
  room.positions[seat]=next;room.moves++;room.linkReady[seat]=false;
  if(room.level===2&&Math.floor(now/2500)%2===0&&same(next,{x:4,y:3})){
    room.positions[seat]={x:1,y:1};room.notice='لمست شعاع البرج. انتظر انطفاء اللون الأحمر ثم اعبر.';
    return true;
  }
  const sequence=PAIRS[room.level];
  if(room.step===sequence.length){
    room.positions.forEach((position,i)=>{if(same(position,{x:7,y:13}))room.keys[i]=true});
    if(room.keys.every(Boolean)&&room.positions.every(p=>same(p,{x:1,y:13}))){
      room.phase='complete';room.elapsed+=now-room.startedAt;
      if(!room.completed.includes(room.level))room.completed.push(room.level);
      room.ready=[false,false];room.notice='أحسنتما! حُفظت المرحلة على اللابتوب.';
    }
  }
  return true;
}
export function activate(room,seat){
  if(room.phase!=='playing'||!room.tokens.every(Boolean))return false;
  const sequence=PAIRS[room.level];
  const plates=room.positions.map(p=>PADS.findIndex(s=>same(p,s))+1);
  const pair=plates.join(',');
  const power=room.level!==1||room.crates.every(c=>same(c,{x:5,y:1}));
  if(!plates[seat]){room.notice='قف على لوحة رمز أولًا، ثم اضغط ربط.';return true}
  room.linkReady[seat]=true;
  if(!power){room.notice='أعيدا الصندوقين إلى مربعي الطاقة أولًا.';return true}
  if(room.step<sequence.length&&plates.every(Boolean)&&room.linkReady.every(Boolean)){
    room.linkReady=[false,false];
    const expected=sequence[room.step];
    if(plates[0]===expected[0]&&plates[1]===expected[1]){
      room.step++;if(room.level===2&&room.step%2===0)room.checkpoint=room.step;
      room.notice=room.step===sequence.length?'اكتملت الدائرة! التقطا المفتاحين ثم التقيا عند بوابتي الخروج.':`نجح الربط ${room.step} / ${sequence.length}. غادرا اللوحتين قبل الربط التالي.`;
    }else if(room.level===2){room.step=room.checkpoint;room.notice='تركيبة غير صحيحة. عدتما إلى آخر نقطة حفظ في اللغز.'}
    else room.notice='الرمزان لا يتطابقان مع الدليل. أخبر شريكك بالرمز الذي تراه.';
  }
  return true;
}
export function bonk(room,seat,now=Date.now()){
  if(room.phase!=='playing'||!room.tokens.every(Boolean)||now-(room.lastHit?.[seat]||0)<2500||now<(room.stunnedUntil?.[seat]||0))return false;
  room.lastHit??=[0,0];room.stunnedUntil??=[0,0];room.lastHit[seat]=now;
  const victim=1-seat;room.stunnedUntil[victim]=now+900;
  room.hit={id:now,from:seat,to:victim};
  room.notice='بُووف! ضربة مزاح… سيقف شريكك خلال لحظة 😄';
  return true;
}
export function nextStage(room,seat){
  if(room.phase!=='complete')return false;room.ready[seat]=true;
  if(room.ready.every(Boolean)&&room.level<2){initStage(room,room.level+1);room.ready=[false,false]}
  return true;
}
