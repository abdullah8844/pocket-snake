from pathlib import Path
import shutil
root=Path(__file__).parent
out=root/'build/android'
src=out/'app/src/main'
(src/'java/com/twinlocks/coop').mkdir(parents=True,exist_ok=True)
(src/'res/drawable').mkdir(parents=True,exist_ok=True)
shutil.copy(root/'native/MainActivity.java',src/'java/com/twinlocks/coop/MainActivity.java')
shutil.copy(root/'public/icon.png',src/'res/drawable/logo.png')
(out/'settings.gradle').write_text("pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }\ndependencyResolutionManagement { repositories { google(); mavenCentral() } }\nrootProject.name='TwinLocks'\ninclude ':app'\n")
(out/'build.gradle').write_text("plugins { id 'com.android.application' version '8.9.2' apply false }\n")
(out/'app/build.gradle').write_text("""plugins { id 'com.android.application' }
android {
 namespace 'com.twinlocks.coop'
 compileSdk 35
 defaultConfig { applicationId 'com.twinlocks.coop'; minSdk 26; targetSdk 35; versionCode 1; versionName '1.0' }
 compileOptions { sourceCompatibility JavaVersion.VERSION_17; targetCompatibility JavaVersion.VERSION_17 }
}
""")
(src/'AndroidManifest.xml').write_text('''<manifest xmlns:android="http://schemas.android.com/apk/res/android"><uses-permission android:name="android.permission.INTERNET"/><application android:label="رابطان" android:icon="@drawable/logo" android:theme="@android:style/Theme.Material.NoActionBar" android:usesCleartextTraffic="false" android:allowBackup="false" android:supportsRtl="true"><activity android:name=".MainActivity" android:exported="true"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>''',encoding='utf-8')
print(out.resolve())
