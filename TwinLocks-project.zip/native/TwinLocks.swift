import SwiftUI
import WebKit

struct GameWebView: UIViewRepresentable {
    let url: URL
    func makeUIView(context: Context) -> WKWebView {
        let web = WKWebView()
        web.isOpaque = false
        web.backgroundColor = UIColor(red: 0.06, green: 0.09, blue: 0.12, alpha: 1)
        web.scrollView.bounces = false
        web.load(URLRequest(url: url))
        return web
    }
    func updateUIView(_ web: WKWebView, context: Context) {}
}

struct Home: View {
    @AppStorage("serverURL") private var savedURL = "https://championships-permitted-capability-contamination.trycloudflare.com"
    @State private var address = ""
    @State private var connected: URL?
    @State private var error = ""
    var body: some View {
        ZStack {
            Color(red: 0.06, green: 0.09, blue: 0.12).ignoresSafeArea()
            if let url = connected {
                VStack(spacing: 0) {
                    HStack {
                        Text("رابطان • Twin Locks").font(.caption).foregroundColor(.white)
                        Spacer()
                        Button("الخادم") { connected = nil }.font(.caption)
                    }.padding(10)
                    GameWebView(url: url)
                }
            } else {
                ScrollView {
                    VStack(spacing: 22) {
                        if let image = UIImage(named: "Logo.png") {
                            Image(uiImage: image).resizable().scaledToFit().frame(width: 170, height: 170).clipShape(RoundedRectangle(cornerRadius: 34))
                        }
                        Text("رابطان").font(.system(size: 42, weight: .bold)).foregroundColor(.white)
                        Text("مغامرة لشخصين • ثلاثة عوالم").foregroundColor(.gray)
                        Text("الصق رابط HTTPS الذي يظهر على اللابتوب. يجب أن يبقى الخادم يعمل أثناء اللعب.")
                            .multilineTextAlignment(.center).foregroundColor(.white.opacity(0.7))
                        TextField("https://…trycloudflare.com", text: $address)
                            .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                            .textFieldStyle(.roundedBorder).environment(\.layoutDirection, .leftToRight)
                        Button("الاتصال بالخادم") { connect() }
                            .buttonStyle(.borderedProminent).tint(Color(red: 0.3, green: 0.75, blue: 0.66))
                        Text(error).foregroundColor(.orange).font(.caption)
                        Text("احفظ رمز استعادة دورك داخل اللعبة قبل تغيير رابط الخادم.").font(.caption).foregroundColor(.gray).multilineTextAlignment(.center)
                    }.padding(30).frame(maxWidth: 500)
                }
            }
        }.preferredColorScheme(.dark).onAppear { address = savedURL }
    }
    func connect() {
        guard let url = URL(string: address.trimmingCharacters(in: .whitespacesAndNewlines)),
              url.scheme == "https", url.host != nil, url.user == nil, url.password == nil else {
            error = "أدخل رابط HTTPS صحيحًا للخادم."; return
        }
        savedURL = url.absoluteString; error = ""; connected = url
    }
}

@main
struct TwinLocksApp: App { var body: some Scene { WindowGroup { Home() } } }
