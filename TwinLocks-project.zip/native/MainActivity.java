package com.twinlocks.coop;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.net.Uri;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.widget.*;
import android.text.InputType;

public class MainActivity extends Activity {
  private WebView web;
  private LinearLayout column;
  public void onCreate(Bundle state) { super.onCreate(state); home(); }
  private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density); }
  private TextView label(String text, int size) { TextView v=new TextView(this);v.setText(text);v.setTextSize(size);v.setTextColor(Color.rgb(235,245,239));v.setGravity(17);v.setPadding(0,dp(12),0,dp(12));return v; }
  private void root() {
    column=new LinearLayout(this);column.setOrientation(1);column.setBackgroundColor(Color.rgb(16,24,32));
    column.setPadding(dp(14),dp(24),dp(14),dp(20));setContentView(column);
  }
  private void home() {
    if(web!=null){web.destroy();web=null;}root();
    ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.logo);
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(150),dp(150));lp.gravity=1;column.addView(logo,lp);
    column.addView(label("رابطان • Twin Locks",28));
    column.addView(label("الصق رابط HTTPS الخاص بخادم اللابتوب",16));
    EditText address=new EditText(this);address.setSingleLine(true);address.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);address.setTextColor(Color.WHITE);address.setText(getPreferences(0).getString("serverURL","https://championships-permitted-capability-contamination.trycloudflare.com"));address.setHint("https://…trycloudflare.com");address.setHintTextColor(Color.GRAY);column.addView(address);
    Button connect=new Button(this);connect.setText("الاتصال بالخادم");column.addView(connect);
    column.addView(label("يجب أن يبقى اللابتوب والخادم يعملان أثناء اللعب. احفظ رمز استعادة دورك من داخل اللعبة.",14));
    connect.setOnClickListener(v->{String value=address.getText().toString().trim();Uri uri=Uri.parse(value);if(!"https".equals(uri.getScheme())||uri.getHost()==null||uri.getUserInfo()!=null){Toast.makeText(this,"أدخل رابط HTTPS صحيحًا",Toast.LENGTH_LONG).show();return;}getPreferences(0).edit().putString("serverURL",value).apply();play(value);});
  }
  private void play(String address) {
    root();Button back=new Button(this);back.setText("رابطان • تغيير الخادم");column.addView(back);back.setOnClickListener(v->home());
    web=new WebView(this);web.setBackgroundColor(Color.rgb(16,24,32));web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(false);
    web.setWebViewClient(new WebViewClient(){public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return !"https".equals(request.getUrl().getScheme());}});
    column.addView(web,new LinearLayout.LayoutParams(-1,0,1));web.loadUrl(address);
  }
}
