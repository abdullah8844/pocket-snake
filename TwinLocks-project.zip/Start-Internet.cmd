@echo off
cd /d "%~dp0"
if not exist "cloudflared.exe" (
  echo Put the official Cloudflare cloudflared.exe in this folder first.
  echo https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/downloads/
  pause
  exit /b 1
)
cloudflared.exe tunnel --url http://127.0.0.1:8787 --edge-ip-version 4
pause
