#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
APP="$PWD/build/ios/Payload/TwinLocks.app"
mkdir -p "$APP"
SDK="$(xcrun --sdk iphoneos --show-sdk-path)"
xcrun swiftc native/TwinLocks.swift -parse-as-library -O -sdk "$SDK" -target arm64-apple-ios17.0 -framework SwiftUI -framework UIKit -framework WebKit -o "$APP/TwinLocks"
cp public/icon.png "$APP/Logo.png"
sips -z 120 120 public/icon.png --out "$APP/Icon60@2x.png" >/dev/null
sips -z 180 180 public/icon.png --out "$APP/Icon60@3x.png" >/dev/null
cat > "$APP/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd"><plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>TwinLocks</string><key>CFBundleIdentifier</key><string>com.twinlocks.coop</string><key>CFBundleName</key><string>TwinLocks</string><key>CFBundleDisplayName</key><string>رابطان</string><key>CFBundlePackageType</key><string>APPL</string><key>CFBundleShortVersionString</key><string>1.0</string><key>CFBundleVersion</key><string>1</string><key>MinimumOSVersion</key><string>17.0</string><key>LSRequiresIPhoneOS</key><true/><key>UIDeviceFamily</key><array><integer>1</integer></array><key>UILaunchScreen</key><dict/><key>DTPlatformName</key><string>iphoneos</string><key>UISupportedInterfaceOrientations</key><array><string>UIInterfaceOrientationPortrait</string><string>UIInterfaceOrientationLandscapeLeft</string><string>UIInterfaceOrientationLandscapeRight</string></array><key>CFBundleIcons</key><dict><key>CFBundlePrimaryIcon</key><dict><key>CFBundleIconFiles</key><array><string>Icon60</string></array></dict></dict>
</dict></plist>
PLIST
plutil -convert binary1 "$APP/Info.plist"
printf 'APPL????' > "$APP/PkgInfo"
cd build/ios
zip -qry TwinLocks-unsigned.ipa Payload
