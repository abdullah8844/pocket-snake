const $=id=>document.getElementById(id);
const SYMBOLS=['','●','◆','▲'];const NAMES=['','الدائرة','المعين','المثلث'];
const COLORS=['#6ce4d1','#efb66b'];const PADS=[{x:7,y:3},{x:1,y:7},{x:7,y:11}];
let session;try{session=JSON.parse(localStorage.getItem('twinlocks.session'))}catch{}
let state=null,busy=false,polling=false,held=null,holdTimer,networkErrors=0,lastPaint=0;
const ctx=$('board').getContext('2d');let touchStart, hitId=0, hitStart=0;
const query=new URLSearchParams(location.search);if(query.get('room')&&session?.code!==query.get('room').toUpperCase())session=null;
if(query.get('room'))$('code').value=query.get('room').replace(/[^A-Fa-f0-9]/g,'').slice(0,10).toUpperCase();
async function api(endpoint,data){
 const response=await fetch('/api/'+endpoint,{method:'POST',headers:{'Content-Type':'application/json',...(session?{Authorization:'Bearer '+session.token}:{})},body:JSON.stringify(data),signal:AbortSignal.timeout(7000)});
 const body=await response.json();if(!response.ok)throw new Error(body.error||'تعذر الاتصال');return body;
}
function storeSession(value){session=value;localStorage.setItem('twinlocks.session',JSON.stringify(value));$('lobby').hidden=true;$('game').hidden=false;poll()}
async function connect(type){$('error').textContent='';$('create').disabled=$('join').disabled=true;try{const result=await api(type,{code:$('code').value});storeSession(result)}catch(e){$('error').textContent=e.message}finally{$('create').disabled=$('join').disabled=false}}
$('create').onclick=()=>connect('create');$('join').onclick=()=>connect('join');$('code').addEventListener('input',()=>{$('code').value=$('code').value.toUpperCase().replace(/[^A-F0-9]/g,'')});
$('restore').onclick=()=>{const value=$('recovery').value.trim();if(!/^[A-F0-9]{10}\.[a-f0-9]{48}$/.test(value)){$('error').textContent='رمز الاستعادة غير صحيح';return}const [code,token]=value.split('.');storeSession({code,token})};
async function poll(){
 if(!session||polling||busy)return;polling=true;
 try{const response=await fetch('/api/state?code='+encodeURIComponent(session.code),{headers:{Authorization:'Bearer '+session.token},cache:'no-store',signal:AbortSignal.timeout(7000)});const data=await response.json();if(!response.ok)throw new Error(data.error);state=data;networkErrors=0;render()}
 catch(e){networkErrors++;$('connection').textContent='انقطع الاتصال؛ نحاول مجددًا';if(networkErrors===3)$('notice').textContent='تأكد من تشغيل خادم اللابتوب والرابط. التقدم محفوظ. '+e.message}
 finally{polling=false}
}
setInterval(poll,300);
async function act(action,data={}){
 if(!session||busy)return;busy=true;while(polling)await new Promise(resolve=>setTimeout(resolve,20));
 try{state=await api(action,{code:session.code,...data});networkErrors=0;render()}catch(e){$('notice').textContent=e.message}finally{busy=false}
}
function direction(dx,dy){if(state?.phase==='playing')act('move',{dx,dy})}
function release(){held=null;clearInterval(holdTimer)}
document.querySelectorAll('[data-d]').forEach(button=>{
 button.addEventListener('pointerdown',event=>{event.preventDefault();release();button.setPointerCapture(event.pointerId);held=button.dataset.d.split(',').map(Number);direction(...held);holdTimer=setInterval(()=>{if(held)direction(...held)},145)});
 button.addEventListener('pointerup',release);button.addEventListener('pointercancel',release);button.addEventListener('lostpointercapture',release);
});
window.addEventListener('blur',release);document.addEventListener('visibilitychange',()=>{release();if(!document.hidden)poll()});
const keys={ArrowUp:[0,-1],w:[0,-1],ArrowDown:[0,1],s:[0,1],ArrowLeft:[-1,0],a:[-1,0],ArrowRight:[1,0],d:[1,0]};
document.addEventListener('keydown',e=>{if(keys[e.key]&&state&&!['INPUT','TEXTAREA'].includes(e.target.tagName)){e.preventDefault();direction(...keys[e.key])}});
$('board').addEventListener('pointerdown',e=>{touchStart={x:e.clientX,y:e.clientY};$('board').setPointerCapture(e.pointerId)});
$('board').addEventListener('pointerup',e=>{if(!touchStart)return;const dx=e.clientX-touchStart.x,dy=e.clientY-touchStart.y;touchStart=null;if(Math.max(Math.abs(dx),Math.abs(dy))>12){if(Math.abs(dx)>Math.abs(dy))direction(Math.sign(dx),0);else direction(0,Math.sign(dy))}});
$('bonk').onclick=()=>act('bonk');
$('link').onclick=()=>act('link');
$('reset').onclick=()=>act('reset-position');$('next').onclick=()=>act('next');
async function copy(text){try{await navigator.clipboard.writeText(text);return true}catch{return false}}
$('copy').onclick=async()=>{const invitation=location.origin+'/?room='+session.code;if(await copy(invitation))$('notice').textContent='نُسخ رابط الدعوة. أرسله لشريكك.';else $('notice').textContent='رمز الغرفة: '+session.code};
$('backup').onclick=async()=>{const value=session.code+'.'+session.token;if(await copy(value))$('backup-status').textContent='نُسخ رمزك الخاص. احتفظ به لاستعادة دورك.';else $('backup-status').textContent=value};
$('leave').onclick=()=>{release();state=null;session=null;$('game').hidden=true;$('lobby').hidden=false;$('error').textContent='التقدم محفوظ. اضغط استعادة الجلسة السابقة للعودة.';const button=document.createElement('button');button.textContent='استعادة الجلسة السابقة';button.onclick=()=>{const previous=JSON.parse(localStorage.getItem('twinlocks.session'));storeSession(previous);button.remove()};$('error').appendChild(button)};
function render(){
 if(!state)return;if(state.hit?.id!==hitId){hitId=state.hit?.id||0;hitStart=Date.now()}$('lobby').hidden=true;$('game').hidden=false;
 $('level-label').textContent=`المرحلة 0${state.level+1} من 03 · هدف الوقت ≈ ٥ دقائق`;
 $('title').textContent=state.title;$('connection').textContent=state.online[1-state.seat]?'شريكك متصل':'بانتظار شريكك';
 $('timer').textContent=String(Math.floor(state.elapsed/60)).padStart(2,'0')+':'+String(state.elapsed%60).padStart(2,'0');
 $('progress').replaceChildren(...Array.from({length:state.total},(_,i)=>{const span=document.createElement('span');span.className=i<state.step?'on':'';return span}));
 $('clue-symbol').textContent=state.partnerTarget?SYMBOLS[state.partnerTarget]:'⚿';
 $('clue').textContent=state.partnerTarget?'أخبر شريكك: '+NAMES[state.partnerTarget]:'ابحثا عن المفتاحين';
 const bothCrates=state.crates.length&&state.crates.every(c=>c.x===5&&c.y===1);
 $('instruction').textContent=state.level===1&&!bothCrates?'ادفعا الصندوقين إلى موضع الطاقة المنقّط أولًا.':state.partnerTarget?'اسأله عن رمزك. قفا على الرمزين واضغطا ربط.':'كل لاعب: المفتاح أسفل اليمين، والخروج أسفل اليسار.';
 $('notice').textContent=state.notice;
 $('link').disabled=state.phase!=='playing'||Boolean(state.linkReady?.[state.seat]);$('link').textContent=state.linkReady?.[state.seat]?'بانتظار ربط شريكك…':'ربط الرمزين ◈';
 $('room-label').textContent='رمز الغرفة: '+state.code+' · أنت '+(state.seat===0?'الفيروزي':'الذهبي')+' · المراحل المحفوظة: '+state.completed.map(n=>n+1).join('،');
 $('complete').hidden=state.phase!=='complete';$('next').hidden=state.level===2;
 $('complete-title').textContent=state.level===2?'اكتملت المغامرة! ثلاثة أبواب، وفريق واحد.':'اكتملت المرحلة وحُفظت!';
 $('next').disabled=Boolean(state.ready[state.seat]);$('next').textContent=state.ready[state.seat]?'بانتظار استعداد شريكك…':'جاهز للمرحلة التالية';
 draw();
}
function round(x,y,w,h,r,fill){ctx.fillStyle=fill;ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fill()}
function text(value,x,y,color,size=24){ctx.font=`bold ${size}px Arial`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle=color;ctx.fillText(value,x,y)}
function draw(){
 if(!state)return;const tile=50;ctx.clearRect(0,0,950,750);
 for(let side=0;side<2;side++){
  const ox=side*500;const color=COLORS[side];
  for(let y=0;y<15;y++)for(let x=0;x<9;x++){
   const px=ox+x*tile,py=y*tile;
   if(state.map[y][x]==='#'){round(px+2,py+2,46,46,8,'#243440');round(px+5,py+4,40,3,1,'#304450')}
   else {round(px+2,py+2,46,46,7,'#131f29');ctx.fillStyle='#25343c';ctx.fillRect(px+24,py+24,2,2)}
  }
  PADS.forEach((p,i)=>{round(ox+p.x*tile+5,p.y*tile+5,40,40,12,'#3a3d3b');text(SYMBOLS[i+1],ox+p.x*tile+25,p.y*tile+26,'#e5d6b6',28)});
  const ex=ox+50,ey=650;round(ex+4,ey+3,42,44,10,state.keys.every(Boolean)?'#2e6257':'#344149');text('⌂',ex+25,ey+24,color,32);
  if(state.step===state.total&&!state.keys[side])text('⚿',ox+375,675,'#f9d284',35);
  if(state.level===1){
   ctx.strokeStyle=color;ctx.lineWidth=2;ctx.setLineDash([4,4]);ctx.strokeRect(ox+255,55,40,40);ctx.setLineDash([]);
   const c=state.crates[side];round(ox+c.x*tile+6,c.y*tile+6,38,38,7,'#9d7854');text('✚',ox+c.x*tile+25,c.y*tile+26,'#eed0a7',23);
  }
  if(state.level===2){const hx=ox+200,hy=150;round(hx+3,hy+4,44,42,5,state.hazardOn?'#9b3e4b':'#213b39');if(state.hazardOn){ctx.shadowColor='#ff657a';ctx.shadowBlur=12;round(hx+5,hy+23,40,5,2,'#ff8192');ctx.shadowBlur=0}else text('·',hx+25,hy+25,'#6ce4d1',27)}
  const p=state.positions[side];const px=ox+p.x*tile+25,py=p.y*tile+25;
  const hitAge=Date.now()-hitStart;const falling=state.hit?.to===side&&hitAge<1000;
  ctx.save();if(falling){const f=hitAge/1000;ctx.translate(px,py);ctx.rotate(Math.sin(f*Math.PI)*1.7);ctx.translate(-px,-py-Math.sin(f*Math.PI)*26)}
  ctx.shadowColor=color;ctx.shadowBlur=side===state.seat?15:5;
  round(px-17,py-17,34,35,11,color);ctx.shadowBlur=0;
  round(px-11,py-7,22,11,5,'#153238');ctx.fillStyle='#efffe9';ctx.fillRect(px-7,py-4,3,4);ctx.fillRect(px+4,py-4,3,4);
  if(falling){text('✦',px-25,py-34,'#ffe596',22);text('✧',px+27,py-28,'#fff8d4',18)}
  if(side===state.seat){ctx.strokeStyle='#fff6db';ctx.lineWidth=2;ctx.beginPath();ctx.arc(px,py,23,0,Math.PI*2);ctx.stroke()}
  ctx.restore();
 }
 text('↔',475,375,'#537079',26);
 if(state.hit&&Date.now()-hitStart<700){const t=Math.min(1,(Date.now()-hitStart)/450);const from=state.positions[state.hit.from],to=state.positions[state.hit.to];const fx=state.hit.from*500+from.x*50+25,fy=from.y*50+25,tx=state.hit.to*500+to.x*50+25,ty=to.y*50+25;text('🥊',fx+(tx-fx)*t,fy+(ty-fy)*t-Math.sin(t*Math.PI)*100,'#fff',42);if(t===1)text('بُووف!',tx,ty-55,'#ffe596',28)}
}
if(session){$('lobby').hidden=true;$('game').hidden=false;poll()}

function animate(){if(state&&Date.now()-hitStart<1100)draw();requestAnimationFrame(animate)}requestAnimationFrame(animate);
